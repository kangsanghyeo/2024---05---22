import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

void main() {
  runApp(UserApp());
}

class UserApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '사용자 앱',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: UserHomePage(),
    );
  }
}

class UserHomePage extends StatefulWidget {
  @override
  _UserHomePageState createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  DateTime? _selectedDate;
  TextEditingController _nameController = TextEditingController();
  List<String> _leaveRequests = []; // 외출/외박 신청 목록

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // 배경색을 흰색으로 설정
      appBar: AppBar(
        title: Text('세종고등학교 연문학사 외출/외박 프로그램'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminApp(_leaveRequests)),
              );
            },
            icon: Icon(Icons.admin_panel_settings),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background_image.jpg"), // 배경 이미지 설정
            fit: BoxFit.cover, // 이미지를 화면에 맞게 늘리거나 축소합니다.
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                _selectedDate == null
                    ? '날짜를 선택해주세요.'
                    : '선택한 날짜: ${_selectedDate!.year}년 ${_selectedDate!.month}월 ${_selectedDate!.day}일',
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  _selectDate(context);
                },
                child: Text('날짜 선택'),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: 250, // 입력 칸의 너비를 지정
                child: TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: '학번/이름',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_selectedDate != null) {
                        _applyForLeave('외출');
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('먼저 날짜를 선택해주세요.'),
                        ));
                      }
                    },
                    child: Text('외출 신청'),
                  ),
                  SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (_selectedDate != null) {
                        _applyForLeave('외박');
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('먼저 날짜를 선택해주세요.'),
                        ));
                      }
                    },
                    child: Text('외박 신청'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  void _applyForLeave(String type) async {
    if (_selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('먼저 날짜를 선택해주세요.'),
      ));
      return;
    }

    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('이름을 입력하세요.'),
      ));
      return;
    }

    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formattedDate = formatter.format(_selectedDate!);

    // 외출/외박 신청 정보를 리스트에 추가
    _leaveRequests.add('$formattedDate $type 신청 (${_nameController.text})');

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$type 신청이 완료되었습니다.'),
    ));
  }
}




class AdminApp extends StatelessWidget {
  final List<String> leaveRequests; // 외출/외박 신청 목록

  AdminApp(this.leaveRequests);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '관리자 앱',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AdminHomePage(leaveRequests),
    );
  }
}

class AdminHomePage extends StatefulWidget {
  final List<String> leaveRequests; // 외출/외박 신청 목록

  AdminHomePage(this.leaveRequests);

  @override
  _AdminHomePageState createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('신청 목록'),
      ),
      body: ListView.builder(
        itemCount: widget.leaveRequests.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(widget.leaveRequests[index]),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _approveLeaveRequest(index);
                  },
                  child: Text('승인'),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    _rejectLeaveRequest(index);
                  },
                  child: Text('거절'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _approveLeaveRequest(int index) {
    setState(() {
      // 외출/외박 신청을 승인하는 로직 추가
      print('Approved leave request: ${widget.leaveRequests[index]}');
      widget.leaveRequests.removeAt(index);
    });
  }

  void _rejectLeaveRequest(int index) {
    setState(() {
      // 외출/외박 신청을 거절하는 로직 추가
      print('Rejected leave request: ${widget.leaveRequests[index]}');
      widget.leaveRequests.removeAt(index);
    });
  }
}
